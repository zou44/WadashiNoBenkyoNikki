https://stackoverflow.com/questions/32473158/packageinstaller-silent-install-and-uninstall-of-apps-by-device-owner-androi

https://chat.openai.com/share/e21ccc2e-9587-49f4-b6bb-a30f9c1c746f